#!/bin/sh
doxygen Doxyfile
