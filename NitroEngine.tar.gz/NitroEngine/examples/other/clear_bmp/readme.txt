The depth bitmap is a bit complicated... It is quite difficult to regulate the
depth...

The color you have to use to set the depth is blue. Clear bitmap is in its
farthest point if blue == 255.

If you want to hide everything including the 2D projection, use red.

If someone has a better idea, tell me.

To convert the images, copy Nitro_Texture_Converter.exe here and execute
convert.bat.
