Model downloaded from:

http://telias.free.fr/models_md2_menu.html