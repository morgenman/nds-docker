//	NDSModelExporter by Kasikiare 2008;
//	Using bmp2bin (libNDS - http://www.devkitpro.org)
//	Irrlicht OpenSource Library (irrlicht.sourceforge.net)
//	and NDS_Mesh_Converter (by PadrinatoR).
//
//	Greetings to Dark Knight Ez for DisplayList library. :D

1.Meshes and Textures/Images to convert must be placed in the root directory
of the aplication. Ex.:

	C:\NDS Programs\NDSModelExporter\

2.Result files will be writed on the root directory of the aplication.
3.The output names will have the following format

	<OriginalName>_<OriginalFormat>.bin

4.Green colored textFields in Textures Tab/Panel show that the bmp2bin.exe
was correctly launched but not that the output file is correct. Check result
sizes.

5.The "Convert" button takes effect only over the Tab that is been shown.
