After converting any model with NDS Mesh Converter rename it to "model.bin".
Then execute RemoveColor.bat. This will fix it so that it is affected by lights.
The fixed model will be output to "model_out.bin".
